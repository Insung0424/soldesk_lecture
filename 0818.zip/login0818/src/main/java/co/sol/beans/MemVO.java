package co.sol.beans;

import lombok.Data;

@Data
public class MemVO {

	private String mem_id;
	private String mem_pass;
	private String mem_name;
	
}
