package com.jis.sol.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jis.sol.beans.Test;
import com.jis.sol.beans.Test2;
import com.jis.sol.config.Bbean;

public class MainClass {

	
	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("com/jis/sol/config/beans.xml");
		
		Test t1 = ctx.getBean("t1",Test.class);
		System.out.println(t1.getD1());
		System.out.println(t1.getD2());
		System.out.println(t1.getD3());
		System.out.println(t1.getD4());
		System.out.println(t1.getD5());
		System.out.println(t1.getD6());
		System.out.println("===========");
		
		
		Test2 t2 = ctx.getBean("t2",Test2.class);
		System.out.println(t2.getD1());
		System.out.println(t2.getD2());
		System.out.println(t2.getD3());
		System.out.println(t2.getD4());
		
		
		System.out.println("===========");
		AnnotationConfigApplicationContext atx = new AnnotationConfigApplicationContext(Bbean.class);
		Test at1= atx.getBean("t1",Test.class);
		System.out.println(at1.getD1());
		System.out.println(at1.getD2());
		System.out.println(at1.getD3());
		System.out.println(at1.getD4());
		System.out.println(at1.getD5());
		System.out.println(at1.getD6());
		
		System.out.println("===========");
		Test2 at2 = atx.getBean("tt2",Test2.class);
		System.out.println(at2.getD1());
		System.out.println(at2.getD2());
		System.out.println(at2.getD3());
		System.out.println(at2.getD4());
	}

}
