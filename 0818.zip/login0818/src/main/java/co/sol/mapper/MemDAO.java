package co.sol.mapper;

import co.sol.beans.MemVO;

public interface MemDAO {

	public void submit(MemVO m);
	
	public MemVO log(String mem_id,String mem_pass);
}
