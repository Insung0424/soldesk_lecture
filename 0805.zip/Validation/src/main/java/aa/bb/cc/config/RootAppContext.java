package aa.bb.cc.config;

import org.springframework.context.annotation.Configuration;


@Configuration
public class RootAppContext {

	
}
