package aa.bb.cc.beans;


public class Data4 {

}
