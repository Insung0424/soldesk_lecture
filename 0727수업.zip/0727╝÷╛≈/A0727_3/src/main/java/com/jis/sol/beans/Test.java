package com.jis.sol.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class Test {
	
	private int d1;
	private Data d2;
	
	@Autowired
	private Data d3;
	
	@Autowired
	@Qualifier("q4")
	private Data2 d4;
	
	@Autowired
	@Qualifier("q5")
	private Data2 d5;
	
	@Autowired(required = false)
	@Qualifier("q6")
	private Data2 d6;
	
	
	public Data2 getD6() {
		return d6;
	}
	public void setD6(Data2 d6) {
		this.d6 = d6;
	}
	public Data2 getD4() {
		return d4;
	}
	public void setD4(Data2 d4) {
		this.d4 = d4;
	}
	public Data2 getD5() {
		return d5;
	}
	public void setD5(Data2 d5) {
		this.d5 = d5;
	}
	public int getD1() {
		return d1;
	}
	public void setD1(int d1) {
		this.d1 = d1;
	}
	public Data getD2() {
		return d2;
	}
	public void setD2(Data d2) {
		this.d2 = d2;
	}
	public Data getD3() {
		return d3;
	}
	public void setD3(Data d3) {
		this.d3 = d3;
	}
	
}
