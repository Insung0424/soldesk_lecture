package aa.bb.cc.db;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class JdbcDAO {

	//Bbean에서 주입받은 값을 jdbctemple에 저장
	@Autowired
	private JdbcTemplate jdbctemple;

	public JdbcTemplate getJdbctemple() {
		return jdbctemple;
	}
	
	//mapperclass에서 주입받은 값을 mapper에 저장
	@Autowired
	private MapperClass mapper;
	
	
	
}
