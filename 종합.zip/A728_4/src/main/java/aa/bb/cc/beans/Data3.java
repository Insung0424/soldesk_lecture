package aa.bb.cc.beans;

import org.springframework.stereotype.Component;

@Component("o1")
public class Data3 {

}
