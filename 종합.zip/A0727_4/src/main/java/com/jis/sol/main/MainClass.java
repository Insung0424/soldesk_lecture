package com.jis.sol.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jis.sol.beans.Test;
import com.jis.sol.beans.Test2;
import com.jis.sol.config.Bbean;

public class MainClass {

	
	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("com/jis/sol/config/beans.xml");
		AnnotationConfigApplicationContext atx = new AnnotationConfigApplicationContext(Bbean.class);
		
		Test t = ctx.getBean("aa",Test.class);
		System.out.println(t);
		
		Test2 t2 = ctx.getBean("bb",Test2.class);
		System.out.println(t2);
		ctx.close();
				
		
	}

}
