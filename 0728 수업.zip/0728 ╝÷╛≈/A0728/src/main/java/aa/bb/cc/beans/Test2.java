package aa.bb.cc.beans;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

public class Test2 {
	
	public Test2() {
		System.out.println("test2");
	}
	
	@PostConstruct
	public void i2() {
		System.out.println("init2");
	}
	
	@PreDestroy
	public void des2() {
		System.out.println("des2");
	}
}
