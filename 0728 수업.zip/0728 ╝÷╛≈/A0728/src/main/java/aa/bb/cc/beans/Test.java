package aa.bb.cc.beans;

public class Test {
	public Test() {
		System.out.println("test");
	}
	public void i1() {
		System.out.println("init");
	}
	public void des1() {
		System.out.println("destroy");
	}
}
