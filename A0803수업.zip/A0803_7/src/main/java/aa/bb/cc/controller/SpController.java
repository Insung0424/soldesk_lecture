package aa.bb.cc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SpController {
	
	@GetMapping("/t1")
	public String t1() {
		return "redirect:/s1";
	}
	
	@GetMapping("/s1")
	public String s1() {
		return "s1";
	}
	
	@GetMapping("/t2")
	public String t2() {
		return "forward:/s2";
	}
	@GetMapping("/s2")
	public String s2() {
		return "s2";
	}
}
