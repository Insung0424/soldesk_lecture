package aa.bb.cc.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class SpController {
	
	@GetMapping("/t1")
	public String t1(HttpServletRequest request) {
		request.setAttribute("d1", "in");
		return "forward:/final1";
	}
	@GetMapping("/final1")
	public String f1(HttpServletRequest request) {
		String str = (String) request.getAttribute("d1");
		System.out.println(str);
		return "final1";
	}
	
	
}
