package com.jis.sol.config;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.jis.sol.beans.Data;
import com.jis.sol.beans.Data2;
import com.jis.sol.beans.Data3;
import com.jis.sol.beans.Data4;
import com.jis.sol.beans.Test;
import com.jis.sol.beans.Test2;

@Configuration
public class Bbean {

	@Bean
	public Test t1() { 
		return new Test();
	}
	@Bean
	public Data d3() {
		return new Data();
	}
	@Bean
	public Data2 q4() {
		return new Data2();
	}
	@Bean
	public Data2 q5() {
		return new Data2();
	}
	
	
	// TEST2
	@Bean(autowire=Autowire.BY_TYPE)
	public Test2 tt2() {
		return new Test2();
	}
	@Bean
	public Data3 dd3() {
		return new Data3();
	}
	@Bean
	public Data4 dd4() {
		return new Data4();
	}
	
	
			
}
