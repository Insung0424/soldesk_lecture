package com.jis.sol.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import com.jis.sol.beans.Test;
import com.jis.sol.beans.Test2;
import com.jis.sol.beans.Test3;

@Configuration
public class Bbean {

	@Bean
	public Test a1() {
		Test t1 = new Test();
		return t1;
	}
	
	@Bean(name="tt")
	public Test a2() {
		Test t1 = new Test();
		return t1;
	}
	
	@Bean
	@Lazy
	public Test2 a3() {
		Test2 t2 = new Test2();
		return t2;
	}
	
	@Bean
	@Scope("prototype")
	public Test3 a4() {
		Test3 t = new Test3();
		return t;
	}
}
