package com.jis.sol.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jis.sol.beans.Test;
import com.jis.sol.beans.Test2;
import com.jis.sol.beans.Test3;
import com.jis.sol.config.Bbean;

public class MainClass {

	
	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("com/jis/sol/config/beans.xml");
		
		Test2 t2 = ctx.getBean("t2",Test2.class);
		System.out.println(t2);
		System.out.println("====================");
		
		Test3 t31 = ctx.getBean("t3",Test3.class);
		System.out.println(t31);
		Test3 t32 = ctx.getBean("t3",Test3.class);
		System.out.println(t32);
		
		AnnotationConfigApplicationContext ctx2=
				new AnnotationConfigApplicationContext(Bbean.class);
		// bean 설정이 되있는 자바파일 로딩
		
		System.out.println("==================");
		Test t1 = ctx2.getBean("a1",Test.class);
		System.out.println(t1);
		
		Test ttn = ctx2.getBean("tt",Test.class);
		System.out.println(ttn);
//		Test ttid = ctx2.getBean("a2",Test.class);
//		System.out.println(ttid); 
//		bean 에 name 을 지정해주면 메소드이름으로는 사용할 수 없다
		
		System.out.println("=====================");
		
		Test2 a3 = ctx2.getBean("a3",Test2.class);
		System.out.println(a3);
		Test2 a31 = ctx2.getBean("a3",Test2.class);
		System.out.println(a31);
		System.out.println("=====================");
		
		Test3 a41 = ctx2.getBean("a4",Test3.class);
		System.out.println(a41);
		Test3 a42 = ctx2.getBean("a4",Test3.class);
		System.out.println(a42);
	}

}
