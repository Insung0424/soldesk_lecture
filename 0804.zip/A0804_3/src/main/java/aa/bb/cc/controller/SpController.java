package aa.bb.cc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;

import aa.bb.cc.beans.Data;

@Controller
@SessionAttributes({"session1","session2"})
public class SpController {
	
	@ModelAttribute("session1")
	public Data session1() {
		return new Data(); 
		// Data객체의 주소값을 반환받음
		//자동으로 session영역에 등록됨
	}
	
	@ModelAttribute("session2")
	public Data session2() {
		return new Data();
	}
	
	@GetMapping("/t1")
	public String t1(HttpSession session) {
		session.setAttribute("d1", "in");
		
		return "t1";
	}
	
	@GetMapping("/t2")
	public String t2(HttpServletRequest request, HttpSession session) {
		session.setAttribute("d1", "in");
		request.setAttribute("d1", "in");
		return "redirect:/final1";
	}
	@GetMapping("final1")
	public String f1(HttpServletRequest request,HttpSession session) {
		String d1 = (String) request.getAttribute("d1");
		System.out.println("request : " +d1);
		
		String d2 = (String) session.getAttribute("d1");
		System.out.println("session : " +d2);
		
		return "final1";
	}
	
	@GetMapping("/t3")
	public String t3(HttpServletRequest request, HttpSession session) {
		session.setAttribute("d1", "in");
		request.setAttribute("d1", "in");
		return "forward:/final2";
	}
	@GetMapping("final2")
	public String f2(HttpServletRequest request,HttpSession session) {
		String d1 = (String) request.getAttribute("d1");
		System.out.println("request : " +d1);
		
		String d2 = (String) session.getAttribute("d1");
		System.out.println("session : " +d2);
		
		return "final2";
	}
	
	@GetMapping("/t4")
	public String t4(@SessionAttribute("bb") Data dd) {
		dd.setD1("in");
		dd.setD2("out");
		
		return "t4";
	}
	@GetMapping("/final4")
	public String f4(Data dd) {
		
		System.out.println(dd.getD1());
		System.out.println(dd.getD2());
		return "final4";
	}
	
	@GetMapping("/t5")
	public String t5(@ModelAttribute("session1") Data s1,
			@ModelAttribute("session2") Data s2) {
		
		s1.setD1("in");
		s1.setD2("out");
		s2.setD1("up");
		s2.setD2("down");
		
		return "t5";
	}
	
	
	
}
