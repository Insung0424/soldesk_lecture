package aa.bb.cc.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import aa.bb.cc.beans.Test2;
import aa.bb.cc.beans.Test3;
import aa.bb.cc.beans.Test4;
import aa.bb.cc.beans.Test5;
import aa.bb.cc.beans.Test6;
import aa.bb.cc.config.Bbean;

public class MainClass {
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext atx =
				new AnnotationConfigApplicationContext(Bbean.class);
		
		Test2 t2 = atx.getBean("t2",Test2.class);
		// 객체가 생성되면서 생성자 호출
		
		Test3 t3 = atx.getBean("t3",Test3.class);
		System.out.println(t3);
		System.out.println(t3.getD1());
		System.out.println(t3.getD2());
		System.out.println("===============");
		
		Test4 t4 = atx.getBean("t4",Test4.class);
		System.out.println(t4.getD1());
		System.out.println(t4.getD2());
		System.out.println("===============");
		
		Test5 t5 = atx.getBean("t5",Test5.class);
		System.out.println(t5.getD1());
		System.out.println(t5.getD2());
		System.out.println("===============");
		
		Test6 t6 = atx.getBean("t6",Test6.class);
		System.out.println(t6.getDd());
		System.out.println(t6.getDd2());
		
		atx.close();
		
	
	}
}
