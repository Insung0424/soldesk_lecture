package aa.bb.cc.beans;

import org.springframework.stereotype.Component;

@Component("com1")
public class Test2 {
	public Test2() {
		System.out.println("test2");
	}
}
