package aa.bb.cc.beans;


public class Test {
	
	private Data d1;

	public Data getD1() {
		return d1;
	}

	public void setD1(Data d1) {
		this.d1 = d1;
	}
	
}
