package aa.bb.cc.db;

public class JdbcDAO {

}
