package aa.bb.cc.config;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import aa.bb.cc.beans.Data;
import aa.bb.cc.beans.Data2;
import aa.bb.cc.beans.Test;
import aa.bb.cc.beans.Test2;


@Configuration
@ComponentScan(basePackages = "aa.bb.cc.beans")
public class Bbean {

	@Bean(autowire = Autowire.BY_NAME)
	public Test t1() {
		return new Test();
	}
	
	@Bean
	public Data d1() {
		return new Data();
	}
	
	@Bean(autowire = Autowire.BY_TYPE)
	public Test2 t2() {
		return new Test2();
	}
	
	@Bean
	public Data2 o() {
		return new Data2();
	}
	
}
