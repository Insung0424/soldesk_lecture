package aa.bb.cc.beans;

import org.springframework.stereotype.Component;

@Component("o3")
public class Data3 {

}
