package com.jis.sol.beans;

public class Test2 {
	
	public Test2() {
		System.out.println("test2");
	}
	public void default_init() {
		System.out.println("default init");
	}
	public void default_destroy() {
		System.out.println("default destroy");
	}
	public void b1_init() {
		System.out.println("b1 init");
	}
	public void b1_destroy() {
		System.out.println("b1 destroy");
	}
}
