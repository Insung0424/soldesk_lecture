package aa.bb.cc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import aa.bb.cc.beans.Data;

@Controller
public class SpController {
	
	@PostMapping("/t1")
	public String a(@ModelAttribute Data dd) {
		System.out.println(dd.getD1());
		System.out.println(dd.getD2());
		
		return "t1";
	}
	
	@PostMapping("t2")
	public String a2(@ModelAttribute("spring") Data dd){
		return "t2";
	}
	
	@GetMapping("/t3/{d1}/{d2}/{d3}")
	public String a3(@PathVariable int d1,@PathVariable int d2,
			@PathVariable int d3) {
		System.out.println(d1);
		System.out.println(d2);
		System.out.println(d3);
		
		return "final";
	}
}
