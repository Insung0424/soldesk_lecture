package aa.bb.cc.advisor;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Order(2) //로드 순서 지정
public class Ad {

	@Around("execution(* m1())")
	public Object a1(ProceedingJoinPoint p) throws Throwable{
		System.out.println("around obj 1");
		Object obj = p.proceed();
		System.out.println("around obj 2");
		return obj;
	}
	
	@After("execution(* m1())")
	public void af1() {
		System.out.println("after");
	}
	
}
