package aa.bb.cc.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import aa.bb.cc.config.Bbean;

public class MainClass {
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext atx= new AnnotationConfigApplicationContext(Bbean.class);
		
		
		
	}
}
