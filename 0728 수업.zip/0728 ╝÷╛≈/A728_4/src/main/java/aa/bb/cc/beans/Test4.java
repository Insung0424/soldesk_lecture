package aa.bb.cc.beans;


public class Test4 {
	
	private Data2 d2;

	public Data2 getD2() {
		return d2;
	}

	public void setD2(Data2 d2) {
		this.d2 = d2;
	}
	
	
	
}
