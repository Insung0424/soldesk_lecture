package aa.bb.cc.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import aa.bb.cc.beans.Data3;
import aa.bb.cc.beans.Data4;
import aa.bb.cc.beans.Data5;
import aa.bb.cc.beans.Test3;


@Configuration
@ComponentScan(basePackages = "aa.bb.cc.beans")
public class Bbean {

	@Bean
	public Data3 d3() {
		return new Data3();
	}
	
	@Bean
	public Data3 d4() {
		return new Data3();
	}
	
	@Bean
	public Test3 tt() {
		Test3 t3 = new Test3(20,"java",new Data4(),new Data5());
		return t3;
	}
	
}
