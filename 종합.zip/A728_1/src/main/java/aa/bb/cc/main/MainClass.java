package aa.bb.cc.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import aa.bb.cc.beans.Test;
import aa.bb.cc.beans.Test2;
import aa.bb.cc.beans2.Test3;
import aa.bb.cc.beans2.Test4;
import aa.bb.cc.beans3.Test5;
import aa.bb.cc.config.Bbean;

public class MainClass {
	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("aa/bb/cc/config/Beans.xml");
		
		System.out.println(ctx.getBean(Test.class));
		
		System.out.println("==========================");
		Test2 t2 = ctx.getBean("t2",Test2.class);
		System.out.println(t2);
		Test2 t3 = ctx.getBean("t3",Test2.class);
		System.out.println(t3);
		System.out.println("==========================");
		
		Test3 t4 = ctx.getBean(Test3.class);
		System.out.println(t4);
		System.out.println("==========================");
		
		Test4 t5 = ctx.getBean("b4",Test4.class);
		System.out.println(t5);
		Test4 t6 = ctx.getBean("t4",Test4.class);
		System.out.println(t6);
		System.out.println("==========================");
		
		Test5 t7 = ctx.getBean(Test5.class);
		System.out.println(t7);
		
//		ctx.close();
		System.out.println("==========================");
		AnnotationConfigApplicationContext atx= new AnnotationConfigApplicationContext(Bbean.class);
		
		Test t= atx.getBean("t1",Test.class);
		System.out.println(t);
		Test2 te2= atx.getBean("t2",Test2.class);
		System.out.println(te2);
		Test3 te3= atx.getBean(Test3.class);
		System.out.println(te3);
		Test4 te4= atx.getBean("b4",Test4.class);
		System.out.println(te4);
		Test4 te41= atx.getBean("t4",Test4.class);
		System.out.println(te41);
		Test5 te5= atx.getBean(Test5.class);
		System.out.println(te5);
		
	}
}
