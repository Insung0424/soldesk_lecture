package com.jis.sol.main;

import java.util.List;
import java.util.Map;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jis.sol.beans.Data;
import com.jis.sol.beans.Test;

public class MainClass {

	
	public static void main(String[] args) {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("com/jis/sol/config/beans.xml");
		
		Test t1= ctx.getBean("t1",Test.class);
//		for(String str : t1.getL1()) {
//			System.out.println(str);
//		}
		t1.getL1().forEach(str -> System.out.println(str));
		System.out.println("=================");
		
		Test t2 = ctx.getBean("t2",Test.class);
		t2.getL2().forEach(data -> System.out.println(data));
		System.out.println("=================");
		t2.getS1().forEach(s -> System.out.println(s));
		System.out.println("=================");
		t2.getS2().forEach(data2 -> System.out.println(data2));
		System.out.println("=================");
		Map<String,Object> m1 = t2.getM1();
		String a1 = (String) m1.get("a1");	
		Data a2 = (Data) m1.get("a2");
		Data a3 = (Data) m1.get("a3");
		List<String> a4 = (List<String>) m1.get("a4");
		
		System.out.println(a1);
		System.out.println(a2);
		System.out.println(a3);
		for(String s:a4) {
			System.out.println(s);
		}
		
		
	}

}
