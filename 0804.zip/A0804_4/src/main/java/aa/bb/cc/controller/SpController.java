package aa.bb.cc.controller;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import aa.bb.cc.beans.Data;
import aa.bb.cc.beans.Data2;

@Controller
@SessionAttributes({"session1","session2"})
public class SpController {
	
	@Autowired
	Data d1;
	@Resource(name="b1")
	Data2 d2;
	
	@GetMapping("/t1")
	public String t1() {
		d1.setD1("in");
		d1.setD2("out");
		d2.setD1("down");
		d2.setD2("up");
		
		return "t1";
	}
	@GetMapping("/final1")
	public String f1(Model m) {
		m.addAttribute("data1",d1);
		m.addAttribute("data2",d2);
		
		return "final1";
	}
	
	
	
}
