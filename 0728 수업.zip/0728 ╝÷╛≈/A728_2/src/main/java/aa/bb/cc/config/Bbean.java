package aa.bb.cc.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import aa.bb.cc.beans.Test2;

@Configuration
@ComponentScan(basePackages = "aa.bb.cc.beans")
public class Bbean {

	@Bean
	public Test2 a1() {
		return new Test2();
	}
}
