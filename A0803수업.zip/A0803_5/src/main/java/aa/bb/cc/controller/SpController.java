package aa.bb.cc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import aa.bb.cc.beans.Data;

@Controller
public class SpController {
	
	@GetMapping("/t1")
	public String t1(Data dd) {
		dd.setName("nam");
		dd.setId("n");
		dd.setPw("4");
		
		return "t1";
	}
}
