package aa.bb.cc.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import aa.bb.cc.beans.Test;
import aa.bb.cc.beans.Test2;
import aa.bb.cc.beans.Test3;
import aa.bb.cc.beans.Test4;
import aa.bb.cc.beans.Test5;
import aa.bb.cc.config.Bbean;

public class MainClass {
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext atx= new AnnotationConfigApplicationContext(Bbean.class);
		Test t1 = atx.getBean(Test.class);
		System.out.println(t1);
		Test t2 = atx.getBean(Test.class);
		System.out.println(t2);
		System.out.println("======================");
		
		Test2 t3 = atx.getBean("com1",Test2.class);
		System.out.println(t3);
		Test2 t31 = atx.getBean("a1",Test2.class);
		System.out.println(t31);
		System.out.println("======================");
		
		Test3 t4 = atx.getBean(Test3.class);
		System.out.println(t4);
		System.out.println("======================");
		
		Test4 t5 = atx.getBean(Test4.class);
		System.out.println(t5);
		Test4 t6 = atx.getBean(Test4.class);
		System.out.println(t6);
		System.out.println("======================");
		
		Test5 t7 = atx.getBean(Test5.class);
		System.out.println(t7);
		
		
	}
}
