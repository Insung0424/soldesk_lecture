package aa.bb.cc.beans;

import org.springframework.stereotype.Component;

@Component
public class Data5 {

}
