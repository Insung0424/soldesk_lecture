package aa.bb.cc.db;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import aa.bb.cc.beans.JBean;

@Component
public class JdbcDAO {

	//Bbean에서 주입받은 값을 jdbctemple에 저장
	@Autowired
	private JdbcTemplate jdbctemple;

	//mapperclass에서 주입받은 값을 mapper에 저장
	@Autowired
	private MapperClass mapper;
	
	public void in_sert(JBean jbean) {
		String sql = "insert into sp_table(num1,str1) values(?,?)";
		
		jdbctemple.update(sql,jbean.getNum1(),jbean.getStr1());
		System.out.println("데이터추가");
	}
	
	public List<JBean> sel_ect(){
		String sql = "select num1,str1 from sp_table";
		
		List<JBean> list = jdbctemple.query(sql, mapper);
		// mapper 가 ResultSet을 가지고 있어서 결과값을 받을 수있다
		return list;
				
	}
	
	public void up_date(String name, int num) {
		String sql = "update sp_table set str1=? where num1=?";
		jdbctemple.update(sql, name, num);
		System.out.println("데이터 수정");
	}
	
	public void dele_te(int n) {
		String sql = "delete from sp_table where num1=?";
		jdbctemple.update(sql,n);
		System.out.println("데이터 삭제");
	}
	
	public void delete_all() {
		String sql = "delete from sp_table";
		jdbctemple.update(sql);
		System.out.println("전체삭제");
	}
	
	public void select_all() {
		sel_ect().forEach(
				j -> {
					System.out.println(j.getNum1()+", "+j.getStr1());
				});
	}
	
}
