package aa.bb.cc.beans;

import org.springframework.stereotype.Component;

@Component("o2")
public class Data2 {

}
