package aa.bb.cc.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import aa.bb.cc.beans.Test;
import aa.bb.cc.beans.Test2;
import aa.bb.cc.beans.Test3;
import aa.bb.cc.config.Bbean;

public class MainClass {
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext atx= new AnnotationConfigApplicationContext(Bbean.class);
		Test t = atx.getBean(Test.class);
		System.out.println(t.getD1());
		System.out.println(t.getD2());
		System.out.println(t.getD3());
		System.out.println(t.getD4());
		System.out.println(t.getD5());
		
		System.out.println("==========");
		
		Test2 t2 = atx.getBean(Test2.class);
		System.out.println(t2.getD1());
		System.out.println(t2.getD2());
		System.out.println(t2.getD3());
		System.out.println(t2.getD4());
		System.out.println("==========");
		
		Test3 t3 = atx.getBean("tt",Test3.class);
		System.out.println(t3.getD1());
		System.out.println(t3.getD2());
		System.out.println(t3.getD3());
		System.out.println(t3.getD4());
		System.out.println("==========");
		
		Test3 t31 = atx.getBean("test3",Test3.class);
		// 매개변수가 있고 기본값을 지정한 생성자는 
		// 클래스이름을 소문자로 생성할 수 있다
		System.out.println(t31.getD1());
		System.out.println(t31.getD2());
		System.out.println(t31.getD3());
		System.out.println(t31.getD4());
		System.out.println("==========");
		
		
	}
}
