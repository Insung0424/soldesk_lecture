package aa.bb.cc.db;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import aa.bb.cc.beans.JBean;

@Component
public class MapperClass implements RowMapper<JBean>{
	
	public JBean mapRow(ResultSet rs, int rowNum) throws SQLException{
		JBean jbean = new JBean();
		jbean.setNum1(rs.getInt("num1"));
		jbean.setStr1(rs.getString("str1"));
		
		return jbean;
	}

}
