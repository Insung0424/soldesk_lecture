package aa.bb.cc.beans;

public class Data {

	private int d1;
	private int d2;
	private int[] d3;
	
	
	public int getD1() {
		return d1;
	}
	public void setD1(int d1) {
		this.d1 = d1;
	}
	public int getD2() {
		return d2;
	}
	public void setD2(int d2) {
		this.d2 = d2;
	}
	public int[] getD3() {
		return d3;
	}
	public void setD3(int[] d3) {
		this.d3 = d3;
	}
	
	
}
