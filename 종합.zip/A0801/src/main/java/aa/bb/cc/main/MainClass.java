package aa.bb.cc.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import aa.bb.cc.beans.Bbean;
import aa.bb.cc.config.ConfigClass;

public class MainClass {
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext atx =
				new AnnotationConfigApplicationContext(ConfigClass.class);
		
		Bbean b1 = atx.getBean(Bbean.class);
		b1.m1();
		System.out.println();
		ClassPathXmlApplicationContext ctx =
				new ClassPathXmlApplicationContext("aa/bb/cc/config/beans.xml");
		Bbean b2 = ctx.getBean(Bbean.class);
		b2.m1();
		
	}
}
