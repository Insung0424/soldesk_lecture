package co.jis.sol.main;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.FileSystemResource;

import co.jis.sol.beans.Test;

public class MainClass {
	
	//IOC컨테이너 중 하나인 ApplicationContext를 이용해 xml파일 로딩해서 객체 출력
	//패키지내부
	public static void t1() {
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("co/jis/sol/config/beans.xml");
		
		Test t = (Test) ctx.getBean("test");
		Test t2 = ctx.getBean("test",Test.class);
		System.out.println(t);
		System.out.println(t2);
		ctx.close();
	}
//	ApplicationContext를 이용
	//패키지외부
	public static void t2() {
		FileSystemXmlApplicationContext ctx = new FileSystemXmlApplicationContext("beans.xml");
		
		Test t = (Test) ctx.getBean("t1");
		Test t2 = ctx.getBean("t1",Test.class);
		System.out.println(t);
		System.out.println(t2);
		ctx.close();
	}
	
	//beanFactory 를 이용
	//패키지 내부
	public static void t3() {
		ClassPathResource cre = new ClassPathResource("co/jis/sol/config/beans.xml");
		XmlBeanFactory fac = new XmlBeanFactory(cre);
		Test t1 = (Test) fac.getBean("test");
		Test t2 = fac.getBean("test",Test.class);
		System.out.println(t1);
		System.out.println(t2);
		
	}
	//beanFactory 를 이용
	//패키지 내부
	public static void t4() {
		FileSystemResource re = new FileSystemResource("beans.xml");
		XmlBeanFactory fac = new XmlBeanFactory(re);
		Test t1 = (Test) fac.getBean("t1");
		Test t2 = fac.getBean("t1",Test.class);
		System.out.println(t1);
		System.out.println(t2);
	}

	public static void main(String[] args) {
		
		t1();
		
		t2();
		
		t3();
		
		t4();
		
	}

}
