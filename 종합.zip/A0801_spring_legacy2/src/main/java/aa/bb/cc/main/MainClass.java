package aa.bb.cc.main;

import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import aa.bb.cc.beans.JBean;
import aa.bb.cc.config.Bbean;
import aa.bb.cc.mapper.MapInterface;

public class MainClass {
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext atx =
				new AnnotationConfigApplicationContext(Bbean.class);
		
		MapInterface mf = atx.getBean("mm",MapInterface.class);
				
		JBean b1 = new JBean();
		b1.setNum1(2);
		b1.setStr1("hi");
		mf.in_sert(b1);
		
		JBean b2 = new JBean();
		b2.setNum1(2);
		b2.setStr1("hello");
		mf.up_date(b2);
		
		List<JBean> li = mf.sel_ect();
		for(JBean j : li) {
			System.out.println(j.getNum1() + ", "+ j.getStr1());
		}
		
//		mf.del_ete(2);
		
		System.out.println(mf.sel_ect());
		
	}
}
