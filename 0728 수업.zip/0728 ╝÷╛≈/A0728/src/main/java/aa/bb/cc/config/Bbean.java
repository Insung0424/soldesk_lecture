package aa.bb.cc.config;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

import aa.bb.cc.beans.Data;
import aa.bb.cc.beans.Data2;
import aa.bb.cc.beans.Test;
import aa.bb.cc.beans.Test2;
import aa.bb.cc.beans.Test3;
import aa.bb.cc.beans.Test4;
import aa.bb.cc.beans.Test5;
import aa.bb.cc.beans.Test6;

@Configuration
public class Bbean {

	@Bean(initMethod="i1",destroyMethod="des1")
	@Lazy
	public Test t1() {
		return new Test();
	}
	
	@Bean
	@Lazy
	public Test2 t2() {
		return new Test2();
	}
	
	@Bean
	public Data d1() {
		return new Data();
	}
	
	@Bean
	public Data2 d2() {
		return new Data2();
	}
	
	@Bean(autowire=Autowire.BY_NAME)
	@Lazy
	public Test3 t3() {
		return new Test3();
	}
	
	@Bean
	@Lazy
	public Test4 t4() {
		return new Test4();
	}
	
	@Bean
	@Lazy
	public Test5 t5() {
		return new Test5();
	}
	
	@Bean
	public Test6 t6() {
		return new Test6();
	}
}
