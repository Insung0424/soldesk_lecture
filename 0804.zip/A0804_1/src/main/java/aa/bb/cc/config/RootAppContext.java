package aa.bb.cc.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.context.annotation.RequestScope;

import aa.bb.cc.beans.Data;
import aa.bb.cc.beans.Data2;

@Configuration
public class RootAppContext {

	@Bean
	@RequestScope
	public Data d1() {
		return new Data();
	}
	
	@Bean("b1")
	@RequestScope
	public Data2 d2() {
		return new Data2();
	}
	
}
