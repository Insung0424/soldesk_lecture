package aa.bb.cc.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import aa.bb.cc.beans.Data;

@Controller
public class SpController {
	
	@GetMapping("/t1")
	public String a1(Data dd,Model m) {
		dd.setS1("in");
		dd.setS2("in");
		dd.setS3("in");
		dd.setS4("in");
		
		String[] arr = {"out","up"};
		dd.setS5(arr);
		dd.setS6(arr);
		dd.setS7(arr);
		dd.setS8(arr);
		
		dd.setS9("in");
		dd.setS11("in");
		dd.setS10("in");
		dd.setS12("in");
		
		String[] ary = {"down","center","in"};
		m.addAttribute("ary",ary);
		
		ArrayList<String> ary3 = new ArrayList<>();
		ary3.add("in");
		ary3.add("out");
		ary3.add("down");
		m.addAttribute("ary3",ary3);
		
		return "t1";
	}
}
