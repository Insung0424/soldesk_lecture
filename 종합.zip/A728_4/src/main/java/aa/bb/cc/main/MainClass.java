package aa.bb.cc.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import aa.bb.cc.beans.Test;
import aa.bb.cc.beans.Test2;
import aa.bb.cc.beans.Test3;
import aa.bb.cc.config.Bbean;

public class MainClass {
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext atx= new AnnotationConfigApplicationContext(Bbean.class);
		Test t1 = atx.getBean("t1",Test.class);
		System.out.println(t1.getD1());
		System.out.println("====================");
		Test2 t2 = atx.getBean("t2",Test2.class);
		System.out.println(t2.getD2());
		System.out.println("====================");
		Test3 t3 = atx.getBean(Test3.class);
		System.out.println(t3.getD3());
		System.out.println("====================");
		
		
	}
}
