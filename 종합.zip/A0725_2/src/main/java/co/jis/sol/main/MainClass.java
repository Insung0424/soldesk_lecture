package co.jis.sol.main;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import co.jis.sol.beans.Test;

public class MainClass {
	
	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("co/jis/sol/config/beans.xml");
		Test t1 = ctx.getBean("a1",Test.class);
		System.out.println(t1);
		
		Test t2 = ctx.getBean("a2",Test.class);
		System.out.println(t2);
		
		Test t3 = ctx.getBean("a3",Test.class);
		System.out.println(t3);
		Test t4 = ctx.getBean("a3",Test.class);
		System.out.println(t4);
	}

}
