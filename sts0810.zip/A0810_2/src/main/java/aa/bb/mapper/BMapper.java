package aa.bb.mapper;

import java.util.List;

import aa.bb.main.BoardVO;

public interface BMapper {

	public List<BoardVO> getList();
	
	public String delete(int i);
}
