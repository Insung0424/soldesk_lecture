package aa.bb.cc.beans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class Test3 {
	@Autowired
	private Data3 d3;

	public Data3 getD3() {
		return d3;
	}
}
