package aa.bb.cc.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import aa.bb.cc.beans.JBean;

public interface MapInterface {

	@Select("select num1,str1 from sp_table")
	public List<JBean> sel_ect();
	
	@Insert("insert into sp_table(num1,str1) values(#{num1},#{str1})")
	public void in_sert(JBean jbean);
	
	@Update("update sp_table set str1=#{str1} where num1=#{num1}")
	void up_date(JBean jbean);
	
	@Delete("delete from sp_table where num1=#{num1}")
	void del_ete(int n);
	
}
