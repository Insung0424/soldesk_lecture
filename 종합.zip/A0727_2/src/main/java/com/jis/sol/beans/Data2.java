package com.jis.sol.beans;

public class Data2 {

}
