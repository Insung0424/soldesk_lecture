package com.jis.sol.beans;

public class Test {
	
	public Test() {
		System.out.println("test");
	}
	public void b_init() {
		System.out.println("tset init");
	}
	public void b_destroy() {
		System.out.println("test destroy");
	}
	
}
