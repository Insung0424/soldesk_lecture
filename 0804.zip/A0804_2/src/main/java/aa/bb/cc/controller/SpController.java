package aa.bb.cc.controller;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import aa.bb.cc.beans.Data;
import aa.bb.cc.beans.Data2;
import aa.bb.cc.beans.Data3;

@Controller
public class SpController {
	
	@Autowired
	@Lazy
	Data d1;
	@GetMapping("/t1")
	public String t1() {
		d1.setD1("in");
		d1.setD2("out");
		return "forward:/final1";
	}
	
	@GetMapping("/final1")
	public String f1(Model m) {
		m.addAttribute("dd",d1);
		
		return "final1";
	}
	
	@Resource(name="b1")
	@Lazy
	Data2 d2;
	
	@GetMapping("/t2")
	public String t2() {
		d1.setD1("in");
		d1.setD2("out");
		
		d2.setD3("up");
		d2.setD4("down");
		
		return "forward:/final2";
	}
	@GetMapping("final2")
	public String f2(Model m) {
		m.addAttribute("d1",d1);
		m.addAttribute("d2",d2);
		return "final2";
	}
	
	@Autowired
	@Lazy
	Data3 d3;
	
	@GetMapping("/t3")
	public String t3() {
		d3.setD5("center");
		
		return "forward:/final3";
	}
	@GetMapping("final3")
	public String f3(Model m) {
		m.addAttribute("d3",d3);
		return "final3";
	}
	
}
