package com.jis.sol.config;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.jis.sol.beans.Data;
import com.jis.sol.beans.Data2;
import com.jis.sol.beans.Data3;
import com.jis.sol.beans.Test;
import com.jis.sol.beans.Test2;
import com.jis.sol.beans.Test3;

@Configuration
public class Bbean {

	// 매개변수가 있는 생성자 , 생성자를 통한 주입
	@Bean
	public Test t1() {
		return new Test(1,"text1",new Data());
	}
	
	// 기본생성자에 set , 수정자를 통한 주입
	@Bean
	public Test t2() {
		Test t = new Test();
		t.setD1(2);
		t.setD2("text2");
		t.setD3(new Data());
		return t;
	}
	
	@Bean
	public Data2 d1() {
		return new Data2();
	}
	@Bean
	public Data2 d2() {
		return new Data2();
	}
	
	@Bean(autowire=Autowire.BY_NAME)
	@Autowired
	public Test2 t3() {
		return new Test2();
	}
	
	@Bean(autowire=Autowire.BY_TYPE)
	@Autowired
	public Test3 t4() {
		return new Test3();
	}
	@Bean
	public Data3 d() {
		return new Data3();
	}
	
			
}
