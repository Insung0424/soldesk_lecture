package co.sol.main;

import lombok.Data;

@Data
public class TestDTO {

	private String id;
	private int age;
	
}
