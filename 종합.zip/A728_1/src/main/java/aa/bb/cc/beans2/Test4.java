package aa.bb.cc.beans2;

import org.springframework.stereotype.Component;

@Component("b4")
public class Test4 {
	//b4라는 이름으로 IoC컨테이너에 Test4 객체가 등록됨
	
}
