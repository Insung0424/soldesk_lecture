package aa.bb.cc.controller;

import javax.validation.Valid;

import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import aa.bb.cc.beans.Data;

@Controller
@PropertySources({@PropertySource("/WEB-INF/properties/d1.properties"),
	@PropertySource("/WEB-INF/properties/d2.properties")})
public class SpController {
	
	@GetMapping("/t1")
	public String t1() {
		
		return "t1";
	}
	
	@PostMapping("/po")
	public String po(@Valid Data data1,BindingResult result) {
		System.out.println(data1.getD1());
		System.out.println(data1.getD2());
		
		System.out.println(result);
		
		if(result.hasErrors()) {
			//유효성을 위반했을 때Size,max 위반결과들을 다 가져옴
			for(ObjectError obj:result.getAllErrors()) {
				System.out.println(obj.getDefaultMessage());
				System.out.println(obj.getCode());
				
				String[] codes = obj.getCodes();
				for(String s:codes) {
					System.out.println(s);
					
				}
								//어노테이션명.클래스.필드
				if(codes[0].equals("Size.data1.d1")) {
					System.out.println("d1은 3~10글자까지 쓸 수 있다");
				}else if(codes[1].equals("Max.data1.d2")) {
					System.out.println("d2는 100보다 클 수 없다");
				}
			}
			return "t1";
		}
		return "po";
	}
}
