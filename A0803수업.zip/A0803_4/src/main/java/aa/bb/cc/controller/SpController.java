package aa.bb.cc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

import aa.bb.cc.beans.Data;

@Controller
public class SpController {
	
	@GetMapping("/t1")
	public String t1(Data dd) {
		dd.setName("namgoungminsu");
		dd.setId("ngms");
		dd.setPw("1234");
		dd.setAdr("seoul");
		dd.setEmail("ngms@aa.com");
		
		return "t1";
	}
	
	@GetMapping("/t2")
	public String t2(Data dd) {
		dd.setName("namgoungminsu");
		dd.setId("ngms");
		dd.setPw("1234");
		dd.setAdr("seoul");
		dd.setEmail("ngms@aa.com");
		
		return "t2";
	}

	@GetMapping("/t3")
	public String t3(@ModelAttribute("aa") Data dd) {
		dd.setName("namgoungminsu");
		dd.setId("ngms");
		dd.setPw("1234");
		dd.setAdr("seoul");
		dd.setEmail("ngms@aa.com");
		
		return "t3";
	}

	@GetMapping("/t4")
	public String t4(Model m) {
		Data dd=new Data();
		dd.setName("namgoungminsu");
		dd.setId("ngms");
		dd.setPw("1234");
		dd.setAdr("seoul");
		dd.setEmail("ngms@aa.com");
		m.addAttribute("spring",dd);
		
		return "t4";
	}
}
