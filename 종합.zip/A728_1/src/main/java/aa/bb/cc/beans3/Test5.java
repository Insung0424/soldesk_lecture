package aa.bb.cc.beans3;

import org.springframework.stereotype.Component;

@Component
public class Test5 {
	
	
}
