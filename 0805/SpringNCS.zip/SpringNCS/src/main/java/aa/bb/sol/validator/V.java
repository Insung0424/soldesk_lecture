package aa.bb.sol.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import aa.bb.sol.beans.Member;

public class V implements Validator{

	@Override
	public boolean supports(Class<?> clazz) {
		return Member.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmpty(errors, "phone", "error1");
		
		Member m = (Member) target;
		
		String pnum = m.getPhone();
		if(pnum.contains("-") == false) {
			errors.rejectValue("phone", "error2");
		}
	}

}
