package aa.bb.cc.validator;

import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import aa.bb.cc.beans.Data;

public class Vali implements Validator{

	public boolean supports(Class<?> clazz) {
		return Data.class.isAssignableFrom(clazz);
	}

	public void validate(Object target,Errors errors) {
		ValidationUtils.rejectIfEmpty(errors, "d2", "error2");
		//값이 비어있는지 확인
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "d3", "error3");
		// 값이 비었거나 공백인지 확인
		
		Data d = (Data) target;
		String str1= d.getD2();
		String str2= d.getD3();
		if(str1.length()>10) {
			errors.rejectValue("d2", "error4");
			// 유효성조건을 직접만들어서 검사할 때 사용
			//errors.rejectValue(검사한값, 에러이름);					
		}
		if(str2.contains("@")==false) {
			errors.rejectValue("d3", "error5");
		}
		
	}

	
	
	

}
