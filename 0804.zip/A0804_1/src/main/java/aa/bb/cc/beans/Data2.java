package aa.bb.cc.beans;

public class Data2 {
	
	private String d3;
	private String d4;
	
	public String getD3() {
		return d3;
	}
	public void setD3(String d3) {
		this.d3 = d3;
	}
	public String getD4() {
		return d4;
	}
	public void setD4(String d4) {
		this.d4 = d4;
	}
	
}
