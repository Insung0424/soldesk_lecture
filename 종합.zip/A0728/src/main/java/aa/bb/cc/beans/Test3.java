package aa.bb.cc.beans;

public class Test3 {
	
	private Data d1;
	private Data2 d2;
	
	
	public Data getD1() {
		return d1;
	}
	public void setD1(Data d1) {
		this.d1 = d1;
	}
	public Data2 getD2() {
		return d2;
	}
	public void setD2(Data2 d2) {
		this.d2 = d2;
	}
	
}
