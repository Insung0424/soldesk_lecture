package com.jis.sol.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.jis.sol.beans.Test;

@Configuration
public class Bbean {

	@Bean
	public Test t1() {
		return new Test();
	}
		
}
