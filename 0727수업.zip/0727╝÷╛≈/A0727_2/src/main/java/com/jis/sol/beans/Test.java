package com.jis.sol.beans;

public class Test {
	
	private int d1;
	private String d2;
	private Data d3;
	
	public Test() {}
	
	public Test(int d1, String d2, Data d3) {
		this.d1 = d1;
		this.d2 = d2;
		this.d3 = d3;
	}
	
	public int getD1() {
		return d1;
	}
	public void setD1(int d1) {
		this.d1 = d1;
	}
	public String getD2() {
		return d2;
	}
	public void setD2(String d2) {
		this.d2 = d2;
	}
	public Data getD3() {
		return d3;
	}
	public void setD3(Data d3) {
		this.d3 = d3;
	}
	
	
}
