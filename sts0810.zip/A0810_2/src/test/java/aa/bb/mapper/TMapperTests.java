package aa.bb.mapper;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.extern.slf4j.Slf4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Slf4j
public class TMapperTests {

	@Autowired
	private TMapper tm;
	
	@Test
	public void te() {
		log.info("time==========");
		log.info(tm.getTime());
	}
	
	@Autowired
	private BMapper bm;
	
	@Test
	public void bt() {
		log.info(bm.delete(2));
		log.info(bm.getList().toString());
	}
}
