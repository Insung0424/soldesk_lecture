package com.jis.sol.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.jis.sol.beans.Test;
import com.jis.sol.beans.Test2;
import com.jis.sol.beans.Test3;
import com.jis.sol.config.Bbean;

public class MainClass {

	
	public static void main(String[] args) {
		
		ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext("com/jis/sol/config/beans.xml");
		
		Test t1 = ctx.getBean("t1",Test.class);
		System.out.println(t1.getD1());
		System.out.println(t1.getD2());
		System.out.println(t1.getD3());
		
		System.out.println("==============");
		Test t2 = ctx.getBean("t2",Test.class);
		System.out.println(t2.getD1());
		System.out.println(t2.getD2());
		System.out.println(t2.getD3());
		System.out.println("==============");
		
		Test2 t3 = ctx.getBean("t3",Test2.class);
		System.out.println(t3.getD1());
		System.out.println(t3.getD2());
		System.out.println("==============");
		
		Test3 t4 = ctx.getBean("t4",Test3.class);
		System.out.println(t4.getD1());
		System.out.println(t4.getD2());
		System.out.println("==============");
		
		AnnotationConfigApplicationContext ctx2 = new AnnotationConfigApplicationContext(Bbean.class);
		Test at1 = ctx2.getBean("t1",Test.class);
		System.out.println(at1.getD1());
		System.out.println(at1.getD2());
		System.out.println(at1.getD3());
		System.out.println("==============ctx1");
		
		Test at2 = ctx2.getBean("t2",Test.class);
		System.out.println(at2.getD1());
		System.out.println(at2.getD2());
		System.out.println(at2.getD3());
		System.out.println("==============ctx2");
		
		Test2 at3 = ctx2.getBean("t3",Test2.class);
		System.out.println(at3.getD1());
		System.out.println(at3.getD2());
		System.out.println("==============ctx3");
		
		Test3 at4 = ctx2.getBean("t4",Test3.class);
		System.out.println(at4.getD1());
		System.out.println(at4.getD2());
		System.out.println("==============ctx4");
		
	}

}
