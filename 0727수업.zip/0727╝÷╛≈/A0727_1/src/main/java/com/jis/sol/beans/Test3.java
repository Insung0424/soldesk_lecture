package com.jis.sol.beans;

public class Test3 {
	public Test3() {
		System.out.println("test3");
	}
}
