package aa.bb.cc.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import aa.bb.cc.beans.Test;
import aa.bb.cc.beans.Test2;
import aa.bb.cc.beans2.Test4;

@Configuration
@ComponentScan(basePackages = "aa.bb.cc.beans2")
@ComponentScan(basePackages = "aa.bb.cc.beans3")
public class Bbean {

	@Bean
	public Test t1() {
		return new Test();
	}
	@Bean
	public Test2 t2() {
		return new Test2();
	}
	@Bean
	public Test4 t4() {
		return new Test4();
	}
	
	
	
}
