package aa.bb.cc.beans3;

public class Test6 {

}
