package aa.bb.cc.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@ComponentScan(basePackages = {"aa.bb.cc.beans","aa.bb.cc.advisor"})
@EnableAspectJAutoProxy //aspect를 자동으로 매칭
public class ConfigClass {
	
	
}
