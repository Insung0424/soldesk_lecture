package aa.bb.cc.beans2;

import org.springframework.stereotype.Component;

@Component
public class Test3 {
	
	
}
