package aa.bb.cc.main;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import aa.bb.cc.beans.JBean;
import aa.bb.cc.config.Bbean;
import aa.bb.cc.db.JdbcDAO;

public class MainClass {
	
	public static void main(String[] args) {
		
		AnnotationConfigApplicationContext atx =
				new AnnotationConfigApplicationContext(Bbean.class);
		
		JdbcDAO jdao = atx.getBean(JdbcDAO.class);
		
		JBean b1 = new JBean();
		b1.setNum1(2);
		b1.setStr1("hi");
		jdao.in_sert(b1);
		
		JBean b2 = new JBean();
		b2.setNum1(3);
		b2.setStr1("hello");
		jdao.in_sert(b2);
		
		JBean b3 = new JBean();
		b3.setNum1(1);
		b3.setStr1("spring");
		jdao.in_sert(b3);
		
		jdao.select_all();
		
		jdao.up_date("no jsp",1);
		
		jdao.select_all();
		
		jdao.dele_te(2);
		
		jdao.select_all();
		
		jdao.delete_all();
		
		jdao.select_all();
	}
}
