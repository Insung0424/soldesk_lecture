package aa.bb.sol.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RootAppContext {
	
	

}








