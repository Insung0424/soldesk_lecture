package aa.bb.cc.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import aa.bb.cc.beans.Data;

@Controller
public class SpController {
	
	@GetMapping("/in")
	public String in(Data data) {
		
		return "in";
	}
	
	@PostMapping("/po")
	public String po(@Valid Data data,BindingResult r) {
		if(r.hasErrors()) {
			return "in";
		}
		return "success";
	}
	
//	@InitBinder
//	public void initBinder(WebDataBinder binder) {
//		Vali v1 = new Vali();
//		binder.setValidator(v1);//하나등록
////		binder.addValidators(v1);//여러개등록
//	}
	
}
