package aa.bb.cc.beans;

public class Test {

}
