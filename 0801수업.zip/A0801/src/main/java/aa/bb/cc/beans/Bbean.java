package aa.bb.cc.beans;

import org.springframework.stereotype.Component;

@Component
public class Bbean {

	public void m1() {
		System.out.println("m1");
	}
}
