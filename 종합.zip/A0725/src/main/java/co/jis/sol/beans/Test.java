package co.jis.sol.beans;

public class Test {
	public Test() {
		System.out.println("test");
	}
}
