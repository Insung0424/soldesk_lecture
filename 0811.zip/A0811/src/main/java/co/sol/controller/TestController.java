package co.sol.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import co.sol.main.TestDTO;
import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/test/*")
@Log4j
public class TestController {

	@RequestMapping("")
	public void aa() {
		log.info("hi");
	}
	
	@RequestMapping(value="/aa",method= {RequestMethod.GET,RequestMethod.POST})
	public void bb() {
		log.info("hello");
	}
	
	@GetMapping("/t1")
	public String t1(TestDTO tt) {
		log.info("====================");
		log.info(tt);
		return "t1";
	}
	
	@GetMapping("t2")
	public String t2(@RequestParam("id") String aa,
			@RequestParam("age") int bb) {
		log.info(aa);
		log.info(bb);
		return "t2";
	}
	
	@GetMapping("t3")
	public String t3(TestDTO tt,int p) {
		log.info(tt);
		log.info(p);
		return "test/t3";
	}
	
	@GetMapping("t4")
	public String t4() {
		return "test/t4";
	}
	
	@PostMapping("po")
	public String post1(TestDTO dto,
			@RequestParam("id") String id,@RequestParam("age") int age) {
		dto.setAge(age);
		dto.setId(id);
		log.info(id);
		log.info(age);
		return "test/form";
	}
}
