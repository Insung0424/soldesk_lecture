package co.sol.service;

import java.util.List;

import org.springframework.stereotype.Service;

import aa.bb.main.BoardVO;
import aa.bb.mapper.BMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.log4j.Log4j;

@Service(value = "Bservicedel")
@RequiredArgsConstructor
@Log4j
public class Bservicedel implements BService{
	
	private final BMapper bm;
	
	@Override
	public Long submit(BoardVO bo) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public BoardVO get(int bnum) {
		return bm.read(bnum);
	}

	@Override
	public int modify(BoardVO bo) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int del(int bnum) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<BoardVO> getList() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean update(BoardVO bo) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean dele(int bnum) {
		return bm.delete(bnum) == 1;
	}

}
