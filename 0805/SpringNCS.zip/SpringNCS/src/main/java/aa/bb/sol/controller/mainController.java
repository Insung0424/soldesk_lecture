package aa.bb.sol.controller;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;

import aa.bb.sol.beans.Member;
import aa.bb.sol.validator.V;

@Controller
public class mainController {
	
	@GetMapping("/logout")
	public String main() {
		return "index";
	}

	@GetMapping("/sign_up")
	public String signup(Member member) {
		return "sign_up";
	}
	
	@GetMapping("/sign_in")
	public String signin(Member member) {
		return "sign_in";
	}
	
	@PostMapping("/confirm")
	public String confirm(@SessionAttribute("mem") Member member1,
			Member member2) {
		if(member1.getId().equals(member2.getId()) &&
				member1.getPw().equals(member2.getPw())) {
			return "main";
		}
		return "sign_up";
	}
	
	@PostMapping("/register")
	public String register(@Valid Member m,BindingResult r,HttpSession session) {
		if(r.hasErrors()) {
			return "sign_up";
		}
		session.setAttribute("mem", m);
		System.out.println("세션등록완료");
		return "index";
	}
	
	@GetMapping("/delete")
	public String delete(HttpSession session) {
		session.removeAttribute("mem");
		return "index";
	}
	
	@InitBinder
	public void initBinder(WebDataBinder binder) {
		V customV = new V();
		binder.addValidators(customV);
	}
	
}
